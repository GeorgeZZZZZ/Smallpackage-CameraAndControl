﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 2019.05.13 create this function for all script to use
public interface IPlayerControllerRPG
{
    Rigidbody TargetRigidbody { get; set; }
    void TurnTargetTowardsCameraFacing(float turnSpeed, float targetEulerAngle);
}
public class Methods : IPlayerControllerRPG
{
    public Rigidbody TargetRigidbody { get; set; }

    //	turn according camera facing, typical RPG control system
    public virtual void TurnTargetTowardsCameraFacing(float turnSP, float tar)
    {
        Vector3 ro = new Vector3(0, TargetRigidbody.rotation.eulerAngles.y + 10, 0);
        TargetRigidbody.MoveRotation(Quaternion.Euler(ro));
        //float curYAng = TargetRigidbody.transform.eulerAngles.y;

        Quaternion tempQuat = Quaternion.Euler(new Vector3(0f, tar, 0f));
        Quaternion newAng = Quaternion.RotateTowards(TargetRigidbody.transform.rotation, tempQuat, turnSP * Time.deltaTime);

        if (TargetRigidbody.transform.eulerAngles.y != newAng.eulerAngles.y)
            TargetRigidbody.MoveRotation(newAng);
    }
}